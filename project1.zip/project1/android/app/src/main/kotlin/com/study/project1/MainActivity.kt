package com.study.project1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
